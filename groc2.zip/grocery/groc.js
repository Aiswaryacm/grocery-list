function ajax(){
    var xhttp = new XMLHttpRequest(); 
    
    
    xhttp.onreadystatechange=function()
    {
        if (this.readyState ==4 && this.status==200){ 
                var myObj= this.responseText;
                var Jproduct= JSON.parse(myObj);
                console.log(product);
                var product = Jproduct.product;
             var table= "<caption><b>GROCERY LIST</b></caption>" + "<thead><tr><th> serialNo: </th><th> Name </th><th> Quantity </th><th> Unit </th><th> Brand</th>" ;
             for(var i=0; i<product.length;i++)
             {
                 table += "<tbody><tr><td>" +
                 product[i].serialNo + "</td><td>" +
                 product[i].name + "</td><td>" +
                 product[i].quantity + "</td><td>" +
                 product[i].unit + "</td><td>" +
                 product[i].Brand + "</td></tr></tbody>" ;
             }  
             console.log(table);
             document.getElementById("row").innerHTML= table;
        }
    };
    xhttp.open('GET',"groc.json",true);
xhttp.send();
}